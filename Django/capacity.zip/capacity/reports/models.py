from django.db import models
from locations.models import Location
from gyms.models import Gym

class Report(models.Model):

    gym_name = models.ForeignKey(
        "gyms.Gym",
        related_name="report",
        verbose_name="Спортивный объект",
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    creation_date = models.DateTimeField(
        "Дата последнего изменения",
        auto_now=True,
        auto_now_add=False
    )

    timetable_open = models.TimeField(
        "Время открытия",
        auto_now=False,
        auto_now_add=False
    )

    timetable_close = models.TimeField(
        "Время закрытия",
        auto_now=False,
        auto_now_add=False
    )

    timetable_workinghours = models.TimeField(
        "Время работы",
        auto_now=False,
        auto_now_add=False
    )

    plan_start = models.TimeField(
        "Плановое начало занятия",
        auto_now=False,
        auto_now_add=False
    )

    plan_finish = models.TimeField(
        "Плановое окончание заниятия",
        auto_now=False,
        auto_now_add=False
    )

    plan_duration = models.TimeField(
        "Планования длительность занятия",
        auto_now=False,
        auto_now_add=False
    )

    plan_quantity = models.PositiveSmallIntegerField(
        "Плановое количество человек",
        null=True,
        blank=True
    )

    fact_start = models.TimeField(
        "Фактическое начало занятия",
        auto_now=False,
        auto_now_add=False
    )

    fact_finish = models.TimeField(
        "Фактическре окончание заниятия",
        auto_now=False,
        auto_now_add=False
    )

    fact_duration = models.TimeField(
        "Фактическая длительность занятия",
        auto_now=False,
        auto_now_add=False
    )
    
    fact_quantity = models.PositiveSmallIntegerField(
        "Фактическое количество человек",
        null=True,
        blank=True
    )

    occupant = models.CharField(
        "Арендатор",
        null=False,
        blank=True,
        max_length=200
    )

    stp_group = models.CharField(
        "Группа УТП",
        null=False,
        blank=True,
        max_length=200
    )

    other = models.CharField(
        "Иное",
        null=False,
        blank=True,
        max_length=200
    )

    def __str__(self):
        return str(self.name)

    class Meta:
        verbose_name = 'Отчет'
        verbose_name_plural = 'Отчеты'