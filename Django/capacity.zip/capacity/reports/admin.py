from django.contrib import admin
from . models import Report
# from django.contrib.admin import widgets
from django.forms import widgets
from django.db import models

class ReportAdmin(admin.ModelAdmin):
#     list_display = [field.name for field in Location._meta.get_fields()]  # указанные поля
    list_display = ['gym_name',]  # указанные поля

    class Meta:
        model = Report
 

admin.site.register(Report, ReportAdmin)