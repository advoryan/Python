from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Location(models.Model):

    user = models.ForeignKey(
        User,
        blank=True,
        null=True,
        on_delete=models.PROTECT
    )
    
    name = models.CharField(
        "Наименование объекта",
        null = False,
        blank = False,
        unique = True,
        max_length = 200
    )

    description = models.CharField(
        "Описание",
        null = False,
        blank = True,
        max_length = 500
    )

    # timetable_open = models.TimeField(
    #     "Время открытия",
    #     auto_now=False,
    #     auto_now_add=False
    # )

    # timetable_close = models.TimeField(
    #     "Время закрытия",
    #     auto_now=False,
    #     auto_now_add=False
    # )

    # timetable_workinghours = models.TimeField(
    #     "Время работы",
    #     auto_now=False,
    #     auto_now_add=False
    # )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Спортивный объект'
        verbose_name_plural = 'Спортивные объекты'



