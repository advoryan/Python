from django.contrib import admin
from . models import Location

class LocationAdmin(admin.ModelAdmin):
#     list_display = [field.name for field in Location._meta.get_fields()]  # указанные поля
    list_display = ['name', 'user']  # указанные поля
    
    class Meta:
        model = Location

admin.site.register(Location, LocationAdmin)