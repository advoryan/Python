from django.apps import AppConfig


class GymsConfig(AppConfig):
    name = 'gyms'
