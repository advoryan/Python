from django.contrib import admin
from . models import Gym
from locations.models import Location
from django.urls import reverse

# class GymAdmin(admin.ModelAdmin):
#     list_display = ['name']

#     def locs(self, obj):
#         redirect_url = reverse('admin:gym_changelist')
#         extra = "?name__id__exact=%d" % (obj.id)
#         return "<a href='%s'>Books by author</a>" % (redirect_url + extra)

#     locs.allow_tags = True


# admin.site.register(Gym, GymAdmin)
# admin.site.register(Location)

class GymAdmin(admin.ModelAdmin):
    list_display = ['name', 'rel_location']  # указанные поля
    # readonly_fields = ['get_author_name']
    # def get_author_name(self, location):
    #     return location.name

    class Meta:
        model = Gym

# class BookAdmin(admin.ModelAdmin):
#     readonly_fields = ['get_author_name']
#     [...]

#     def get_author_name(self, book):
#         return book.author.name

admin.site.register(Gym, GymAdmin)
