from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.list import ListView
from django.views.generic.base import TemplateView
from django.views.generic.edit import CreateView, UpdateView
from django.views.generic.edit import DeleteView

from gyms.models import Gym
from django.urls import reverse_lazy
from locations.models import Location
from django.contrib.auth.mixins import PermissionRequiredMixin

class GymsListView(ListView):
    model = Gym

class GymsDetailView(DetailView):
    model = Gym