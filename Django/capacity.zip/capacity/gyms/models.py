from django.db import models

class Gym(models.Model):

    name = models.CharField(
        "Спортивный зал",
        null = False,
        blank = False,
        max_length = 200
    )
    
    rel_location = models.ForeignKey(
        "locations.Location",
        related_name = "gym",
        verbose_name = "Зал",
        null = True,
        blank = True,
        on_delete=models.CASCADE
    )

    description = models.CharField(
        "Описание",
        null = True,
        blank = True,
        max_length = 500
    )

    # timetable_open = models.TimeField(
    #     "Время открытия",
    #     auto_now=False,
    #     auto_now_add=False
    # )

    # timetable_close = models.TimeField(
    #     "Время закрытия",
    #     auto_now=False,
    #     auto_now_add=False
    # )

    # timetable_workinghours = models.TimeField(
    #     "Время работы",
    #     auto_now=False,
    #     auto_now_add=False
    # )

    def __str__(self):
        return str(self.name)

    class Meta:
        verbose_name = 'Зал'
        verbose_name_plural = 'Залы'



