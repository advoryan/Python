
from django.urls import path
from locations.views import LocationsListView


urlpatterns = [
    path('', LocationsListView.as_view(), name='locations-list-view'),    
    # path('<int:pk>', BookDetailView.as_view(), name='book-detail-view'),
    # path('create', BookCreateView.as_view(), name='book-create-view'),
    # path('<int:pk>/update', BookUpdateView.as_view(), name='book-update-view'),
    # path('<int:pk>/delete', BookDeleteView.as_view(), name='book-delete-view'),
]